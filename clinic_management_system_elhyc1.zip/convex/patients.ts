import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const create = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    age: v.number(),
    gender: v.union(v.literal("male"), v.literal("female")),
    medicalHistory: v.optional(v.array(
      v.object({
        date: v.string(),
        condition: v.string(),
        diagnosis: v.string(),
      })
    )),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("patients", args);
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("patients")
      .order("desc")
      .collect();
  },
});
