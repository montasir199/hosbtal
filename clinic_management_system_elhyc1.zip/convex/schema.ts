import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  appointments: defineTable({
    patientId: v.id("patients"),
    doctorId: v.id("doctors"),
    patientName: v.optional(v.string()),
    doctorName: v.optional(v.string()),
    date: v.string(),
    time: v.string(),
    notes: v.optional(v.string()),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("cancelled"), v.literal("scheduled")),
  }).index("by_patient", ["patientId"])
    .index("by_doctor", ["doctorId"]),

  patients: defineTable({
    name: v.string(),
    phone: v.optional(v.string()),
    phoneNumber: v.optional(v.string()),
    age: v.optional(v.number()),
    dateOfBirth: v.optional(v.string()),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"))),
    medicalHistory: v.optional(v.union(v.string(), v.array(
      v.object({
        date: v.string(),
        condition: v.string(),
        diagnosis: v.string(),
      })
    ))),
    userId: v.optional(v.string()),
  }).index("by_name", ["name"])
    .index("by_phone", ["phone"]),

  doctors: defineTable({
    name: v.string(),
    phone: v.optional(v.string()),
    specialization: v.string(),
    availableDays: v.optional(v.array(v.string())),
    workingHours: v.optional(v.object({
      start: v.string(),
      end: v.string(),
    })),
    userId: v.optional(v.string()),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
